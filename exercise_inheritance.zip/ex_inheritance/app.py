from flask import Flask, render_template

#create the object of Flask
app  = Flask(__name__,template_folder='render_template')


#creating a decorator that will define the webpage "/mypage/me"
@app.route('/mypage/me')
def index():
    return render_template('aboutme.html')


#creating a decorator that will define the webpage "/mypage/contact"
@app.route('/mypage/contact')
def Contact():
    return render_template('contact.html')


#run flask app
if __name__ == "__main__":
    app.run(debug=True)
